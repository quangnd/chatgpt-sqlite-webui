"""Generate a wholly synthetic, reproducible ChatGPT export for UI evaluation."""
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
TOPICS = [
 ('Archive MVP — preservation and recovery', 'How should I preserve ChatGPT exports for a small personal archive?', 'Keep the original ZIP files, calculate SHA-256, and use SQLite as a rebuildable reader.\n\nA useful recovery drill includes preserving snapshots, verifying checksums, taking a consistent database backup, and restoring to a separate directory.\n\nThis synthetic discussion uses the search marker archive-checkpoint.'),
 ('Kế hoạch học tiếng Anh — tuần 1', 'Tôi muốn luyện tiếng Anh 20 phút mỗi ngày. Bạn giúp tôi lập kế hoạch nhé?', 'Được chứ!\n\nThứ hai: nghe một đoạn hội thoại ngắn.\nThứ ba: đọc và ghi lại năm từ mới.\nThứ tư: luyện nói về một ngày của bạn.\n\nMục tiêu là luyện đều đặn, không cần học quá nhiều trong một buổi.'),
 ('日本語の学習ノート', '旅行で使える日本語の練習方法を教えてください。', '毎日、短い会話を声に出して練習しましょう。\n\n「駅はどこですか」「おすすめは何ですか」などの表現から始めると便利です。\nこの会話は表示と検索を確認するための架空の例です。'),
 ('中文阅读与搜索示例', '怎样整理长期积累的学习笔记？', '可以按照主题、日期和项目整理。\n\n先保存原始资料，再建立可搜索的阅读副本。定期检查备份是否能够恢复。\n\n关键词：学习笔记、备份恢复、全文搜索。'),
 ('Plan de lectura — biblioteca personal', '¿Cómo puedo organizar una biblioteca digital pequeña?', 'Empieza por conservar los archivos originales y añadir etiquetas sencillas.\n\nUna búsqueda útil debe encontrar títulos, frases y palabras con acentos: información, recuperación y organización.'),
 ('Python — a tiny SQLite backup script', 'Can you show a minimal consistent SQLite backup example?', 'Use the SQLite backup API instead of copying a live WAL database.\n\n```python\nimport sqlite3\nwith sqlite3.connect("reader.db") as src:\n    with sqlite3.connect("backup.db") as dst:\n        src.backup(dst)\n```\n\nCheck integrity after restoration. This is synthetic demonstration code.'),
 ('Weekend itinerary — quiet cafés and museums', 'Please plan a relaxed weekend with time for a museum and a book.', 'Saturday morning: a short walk and coffee.\nSaturday afternoon: visit a local museum.\nSunday: leave a few hours free for reading and planning.\n\nAll places and plans in this archive are fictional.'),
 ('Design review — choosing a simple reader', 'Which features matter most for finding old conversations?', 'Clear titles, readable dates, fast substring search, and a predictable way to switch between current-path and alternative answers.\n\nDownloads are useful, but a text export is a convenience copy rather than a complete historical archive.')]
base = datetime(2024,1,6,9,tzinfo=timezone.utc)
items=[]
for i in range(72):
 title, question, answer = TOPICS[i % len(TOPICS)]
 date = base + timedelta(days=i*13)
 ts = date.timestamp()
 cid=f'demo-{i+1:03d}'
 mapping={}
 def node(key,parent,role,text,children=None):
  return dict(id=key,parent=parent,children=children or [],message=dict(id=cid+'-'+key,author={'role':role},create_time=ts,update_time=ts,content={'content_type':'text','parts':[text]},metadata={}))
 mapping['root']=dict(id='root',parent=None,children=['system'],message=None)
 mapping['system']=node('system','root','system','Synthetic local archive demonstration. No real user conversations.', ['u0'])
 mapping['u0']=node('u0','system','user',question,['a0'])
 mapping['a0']=node('a0','u0','assistant',answer)
 current='a0'
 if i == 0:
  for j in range(1,43):
   u,a=f'u{j}',f'a{j}'
   mapping[current]['children']=[u]
   mapping[u]=node(u,current,'user',f'Archive review question {j}: what should the next recovery check include?', [a])
   mapping[a]=node(a,u,'assistant',f'Check {j}: confirm original ZIP hashes, inspect warning counts, and restore the read database in a separate directory.\n\n'+('A clear recovery record includes the snapshot identity, the test date, and the verification result.\n'*3))
   current=a
  mapping['u0']['children'].append('alternative')
  mapping['alternative']=node('alternative','u0','assistant','Alternative branch: keep an offline copy and test restoring attachments. Branch-only keyword: alternative-snapshot-plan.')
  mapping['a10']['message']['content']['parts']=['Long recovery checklist\n\n'+('\n'.join(f'{k}. Preserve originals, verify SHA-256, inspect the import outcome, and rehearse a restore. Never treat a successful exit code alone as proof of complete historical preservation.' for k in range(1,161)))]
 if i in (2,10,18):
  mapping['u0']['children'].append('alternative')
  mapping['alternative']=node('alternative','u0','assistant','Alternative explanation in another branch. This is preserved independently of the selected current answer.')
 if i==7:
  mapping['a0']['message']['content']={'content_type':'multimodal_text','parts':[answer,{'content_type':'image_asset_pointer','asset_pointer':'synthetic://not-an-external-image'}]}
 items.append(dict(id=cid,title=f'{title} · {i+1:02d}',create_time=ts,update_time=ts+3600,current_node=current,mapping=mapping))
with zipfile.ZipFile(ROOT/'synthetic-ui-demo.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 z.writestr('conversations.json',json.dumps(items,ensure_ascii=False))
 z.writestr('attachments/synthetic-note.txt','Synthetic demonstration attachment. No personal content.')
(ROOT/'fixture-summary.json').write_text(json.dumps(dict(conversations=len(items),nodes=sum(len(x['mapping']) for x in items),date_range=[items[0]['create_time'],items[-1]['create_time']],languages=['English','Vietnamese','Japanese','Chinese','Spanish'],long_conversation_visible_messages=86,branches=4),indent=2)+'\n')
