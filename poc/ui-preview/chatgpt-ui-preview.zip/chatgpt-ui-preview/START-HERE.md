# Try the existing application locally

This bundle contains only synthetic data, screenshots, evidence and demo helpers.
It does not contain a replacement UI. See REVIEW.md for the verified findings.

The simplest way to inspect the actual interface is to open screenshots/01-main.png,
02-conversation-detail.png, 03-search.png and 04-import.png. To interact with it,
run the existing repository on your own machine using the commands below.

## Tested setup

Linux x86_64, CPython 3.12.14, SQLite 3.53.1, Node 24.19.0, npm 11.9.0,
Chromium via Playwright for screenshot/testing only. Chromium/Playwright are not
needed to use the application in your regular browser.

```bash
git clone --branch poc/archive-evaluation https://github.com/quangnd/chatgpt-sqlite-webui.git
cd chatgpt-sqlite-webui
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-web.txt -c constraints-web-py312.txt
cd webui
npm ci --cache /tmp/chatgpt-ui-npm-cache --no-audit --no-fund
npm run typecheck
npm run build
cd ..
```

Set DEMO_DIR to the absolute directory where you extracted this bundle. Use either
the included consistent demo.db or create another reader from the retained ZIP:

```bash
DEMO_DIR="/absolute/path/to/extracted/chatgpt-ui-preview"
python chatgpt_archive.py import --db "$DEMO_DIR/rebuilt-demo.db" --input "$DEMO_DIR/synthetic-ui-demo.zip" --rebuild-fts
python chatgpt_archive.py verify --db "$DEMO_DIR/rebuilt-demo.db"
python chatgpt_archive.py web-index --db "$DEMO_DIR/rebuilt-demo.db"
python chatgpt_archive.py web --db "$DEMO_DIR/rebuilt-demo.db" --host 127.0.0.1 --port 8787
```

Once the server reports it is running, open **http://127.0.0.1:8787/** on that same
machine. This is a local startup address, not a hosted cloud preview. Stop with
Ctrl+C. You can instead point --db to the bundled demo.db to skip reconstruction.
Do not change the bind to 0.0.0.0 for this trial.

Try the following:

1. Scroll the sidebar from 60 loaded conversations to all 72; select different
   languages and change sorting.
2. Sort Oldest and select Archive MVP · 01. In Settings set Message page size to
   50, close Settings, then Load more messages to reach 86.
3. Search archive-checkpoint, 学习笔记, or luyện tiếng Anh. Each has nine results.
4. Search alternative-snapshot-plan: Current path gives zero; All nodes gives one.
5. Download MD/TXT. The all-nodes export includes the alternate answer.
6. Import ZIP, choose the included synthetic-ui-demo.zip, and Start import to see
   actual progress and the completed zero-warning import summary.

The existing Vite development setup is also available:

```bash
# Terminal 1, repository root:
python chatgpt_archive.py web --db "$DEMO_DIR/demo.db" --host 127.0.0.1 --port 8787
# Terminal 2:
cd webui
npm run dev -- --strictPort
```

It serves on local port 5173 and proxies /api to 8787. Browsing/search worked here,
but upload through that proxy returned 403. Use the built application directly on
8787 to test the complete import experience. No source patch is needed for that
README-supported single-port workflow.

Helpers generate_demo.py and check_ui.py reproduce the fixture/browser evaluation.
The generator creates its ZIP exclusively and refuses to overwrite an existing one;
run it in a new directory if regenerating. The browser helper uses environment
paths from this trial and /usr/bin/chromium; adjust those locally if reproducing
screenshots. Browser checks are evidence, not a new application test requirement.
