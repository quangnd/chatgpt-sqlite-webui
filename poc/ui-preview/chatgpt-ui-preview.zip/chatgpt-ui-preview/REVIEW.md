# Existing ChatGPT Archive UI preview

Repository: quangnd/chatgpt-sqlite-webui, branch poc/archive-evaluation, commit ae5508b.
No UI, backend, dependency manifest, lockfile, or tracked build output changed.
No commit, push, merge or deployment was performed for this preview task.

## Open the screenshots

- screenshots/01-main.png — default desktop interface and conversation list.
- screenshots/02-conversation-detail.png — an 86-message conversation, first page.
- screenshots/03-search.png — nine archive-checkpoint matches, highlighted body.
- screenshots/04-import.png — actual selected-ZIP/start-import panel.
- screenshots/05-multilingual.png — Vietnamese search and conversation content.
- screenshots/06-branch-search.png — branch-only result with all-nodes scope.
- screenshots/07-import-complete.png — successful import and counts.
- screenshots/08-vite-upload-limitation.png — actual Vite origin rejection.
- screenshots/09-code-example.png — code/Markdown displayed as text.
- screenshots/10-settings.png — existing appearance and pagination settings.

Screenshots are real Chromium captures of the existing application, not mockups.
Viewport 1600x1000, English UI, Asia/Ho_Chi_Minh timezone. Main four screenshots
and the completed import use FastAPI serving the built React application. The
Vite limitation screenshot uses the existing Vite development server.

## Preview availability

The environment status advertised no capabilities, and the available cloud tools
exposed no authenticated preview/port-forwarding mechanism or accessible preview
hostname. Consequently there is **no verified browser preview URL to provide**.
This is a statement about this session's exposed capabilities, not every Codex
Cloud product/configuration. No tunnel, public bind, remote deployment or account
was created. Only outbound npm package downloads were needed.

The FastAPI server was left bound to 127.0.0.1:8787 inside the environment. That
address is not reachable from your own browser without a separate private route;
it must not be presented as a working remote preview link. Services may end when
the execution environment stops.

## Synthetic data and verified behavior

72 conversations / 376 mapping nodes, dated January 2024 through July 2026.
English, Vietnamese, Japanese, Chinese and Spanish. Four branching conversations;
one has 86 visible current-path messages, an alternate answer, and a ~28k-character
recovery checklist. One synthetic asset pointer and one synthetic text attachment
are included; rich media playback is not demonstrated. Repeated topics make the
search comparisons predictable; this is a functional demonstration, not a realistic
statistical sample of a personal archive or performance benchmark.

See browser-checks.json for 14 successful real-browser checks:

- Existing React application rendered; initial list showed 60 of 72 conversations.
- Scrolling loaded all 72. Sorting and selecting the oldest conversation worked.
- Settings changed message pages to 50; Load more messages reached 86 of 86.
- Download MD and TXT produced complete current-path text, including checklist item
  160 beyond the initially rendered messages. Alternative answer was absent.
- All-nodes view exposed 87 visible messages and included the alternate answer in MD.
- English substring search returned nine conversations and highlighted matches.
- Chinese and Vietnamese queries each returned nine matches; Unicode rendered.
- Browser Back/Forward restored previous search text and result counts.
- Current-path branch-only search returned zero; All nodes returned one.
- Browser ZIP import succeeded: canonical commit yes, 72 conversations, 376 nodes,
  zero skipped elements, zero warnings, original ZIP hash unchanged.
- Final successful browser run had zero JavaScript errors, HTTP errors or external
  requests. SQLite/project verify after import passed. Browser import job data and
  health snapshot are retained separately in the bundle.

The UI is responsive at this small workload; no formal timing or mobile evaluation
was performed. Clipboard copy, every advanced filter, every language, accessibility,
large real exports, media rendering and production use were not exhaustively tested.

## Short usability review

Strengths: a practical local reader with a clear two-pane layout, readable message
roles and dates, incremental loading, useful literal multilingual search with
snippets/highlights, current/all-node scope, convenient full-conversation text
exports, import progress/counts, and adjustable theme/density/layout/page sizes.
It can satisfy a lightweight browsing/search MVP without building another reader.

Usability issues observed: the toolbar and repeated hidden-node notices are dense;
long sidebar titles truncate; current-path/all-nodes is shared by the reader and
sidebar, so changing one also changes later search scope. Branches appear as
all-node results rather than an obvious conversation-tree navigator. Markdown and
code fences display as plain text, with less formatting than ChatGPT. The small
9,616-byte selected demo ZIP is rounded to "0 MB", which is a minor clarity issue.

Development limitation: npm run dev on port 5173 displayed and searched the archive,
but ZIP upload returned HTTP 403: "This page is not allowed to upload to the local
archive server." The existing Vite proxy and backend origin check do not support
this upload path as used here. Serving the built React UI directly through FastAPI
on port 8787 worked, including uploads. No security controls or source files were
changed to bypass the error. The first browser script also assumed reader/sidebar
scope was independent; that test expectation was corrected, not the UI.

Archive MVP limitation: this UI provides a current-state reader, not snapshot history,
revision diffs, immutable media storage or backup/recovery management. Browser import
uses the existing application pipeline and does not enforce the separate Phase 2
controller's admission policy. For an archive, route ingestion through that policy
and use this UI to browse the selected read model. Existing loopback restrictions
are not user authentication; do not expose it publicly.

Recommendation: try this reader locally using the included demo. Adopt it as the
browsing layer if plain-text presentation and basic branch access are acceptable;
keep preservation, ordering and tested backup/restore outside the UI.

## Exact changes and setup notes

All demo files were created outside the repository under /workspace/chatgpt-ui-demo.
The bundle's demo.db was made using SQLite's consistent online backup API; it is
not a blind copy of a live WAL main file. Original synthetic-ui-demo.zip is retained.
Existing npm dependencies were installed and the supported build/typecheck passed.
The first npm attempt failed at the unavailable default /home/agent/.npm cache;
using --cache /tmp/chatgpt-ui-npm-cache fixed installation without changing locks.
Generated dependencies/caches were cleaned afterward using the repository cleaner;
the built application remains available to FastAPI. Git status remained clean.
