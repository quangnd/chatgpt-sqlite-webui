"""Real Chromium interactions against the existing loopback development UI."""
from pathlib import Path
import hashlib,json,re,time
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parent
results=[]
def passed(name,**values):
 results.append(dict(check=name,status='PASS',**values))
 (ROOT/'browser-checks.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(viewport={'width':1600,'height':1000},locale='en-US',timezone_id='Asia/Ho_Chi_Minh',accept_downloads=True)
 errors=[]; failures=[]; external=[]
 page=context.new_page()
 page.on('pageerror',lambda err:errors.append(str(err)))
 page.on('response',lambda r:failures.append({'status':r.status,'url':r.url}) if r.status>=400 else None)
 def route(r):
  if not r.request.url.startswith(('http://127.0.0.1:5173/','http://127.0.0.1:8787/','data:','blob:')):
   external.append(r.request.url); r.abort()
  else:r.continue_()
 page.route('**/*',route)
 page.goto('http://127.0.0.1:8787/',wait_until='networkidle')
 expect(page.locator('.results-meta')).to_have_text('60 of 72 conversations')
 expect(page.locator('h1')).to_contain_text('Design review')
 page.screenshot(path=str(ROOT/'screenshots/01-main.png'),full_page=True)
 passed('initial render',loaded=60,total=72,react=True)
 page.locator('.conversation-list').evaluate('(el)=>el.scrollTop=el.scrollHeight')
 expect(page.locator('.results-meta')).to_have_text('72 of 72 conversations')
 passed('conversation pagination',before=60,after=72,method='scroll-to-load')
 page.get_by_role('button',name='Settings',exact=True).click()
 page.get_by_label('Message page size',exact=True).fill('50')
 page.get_by_role('button',name='Close',exact=True).click()
 page.get_by_label('Sort',exact=True).select_option('oldest')
 expect(page.locator('.conversation-item').first).to_contain_text('Archive MVP')
 page.locator('.conversation-item').first.click()
 expect(page.locator('h1')).to_have_text('Archive MVP — preservation and recovery · 01')
 expect(page.locator('.message-page-meta')).to_contain_text('50 of 86')
 page.locator('.conversation-list').evaluate('(el)=>el.scrollTop=0')
 page.screenshot(path=str(ROOT/'screenshots/02-conversation-detail.png'),full_page=True)
 passed('selection and sort',conversation='demo-001',visible_messages=86)
 page.get_by_role('button',name='Load more messages',exact=True).click()
 expect(page.locator('.message-page-meta')).to_contain_text('86 of 86')
 passed('message pagination',before=50,after=86)
 # Export actual browser downloads and inspect whole-file content.
 for label,extension in [('Download MD','md'),('Download TXT','txt')]:
  with page.expect_download() as pending:
   page.get_by_role('link',name=label,exact=True).click()
  download=pending.value
  target=ROOT/('sample-export.'+extension);download.save_as(target)
  text=target.read_text()
  assert 'archive-checkpoint' in text and '160. Preserve originals' in text
  assert 'alternative-snapshot-plan' not in text
  passed('current-path '+extension+' download',bytes=target.stat().st_size,filename=download.suggested_filename)
 page.get_by_label('Message path',exact=True).select_option('all')
 expect(page.locator('.message-page-meta')).to_contain_text('87')
 with page.expect_download() as pending:
  page.get_by_role('link',name='Download MD',exact=True).click()
 pending.value.save_as(ROOT/'sample-all-nodes.md')
 assert 'alternative-snapshot-plan' in (ROOT/'sample-all-nodes.md').read_text()
 passed('branch access and export',current_path_visible=86,all_nodes_visible=87)
 # Search is committed through Enter, and tested with literal multilingual text.
 def search(text):
  page.locator('#global-search').fill(text)
  page.locator('#global-search').press('Enter')
 search('archive-checkpoint')
 expect(page.locator('.results-meta')).to_have_text('9 of 9 conversations')
 page.locator('.conversation-item').filter(has_text='· 65').click()
 expect(page.locator('h1')).to_contain_text('· 65')
 expect(page.locator('mark').first).to_be_visible()
 page.screenshot(path=str(ROOT/'screenshots/03-search.png'),full_page=True)
 passed('substring search and highlight',query='archive-checkpoint',results=9)
 search('学习笔记')
 expect(page.locator('.results-meta')).to_have_text('9 of 9 conversations')
 passed('Chinese search',query='学习笔记',results=9)
 page.go_back()
 expect(page.locator('#global-search')).to_have_value('archive-checkpoint')
 expect(page.locator('.results-meta')).to_have_text('9 of 9 conversations')
 page.go_forward()
 expect(page.locator('#global-search')).to_have_value('学习笔记')
 expect(page.locator('.results-meta')).to_have_text('9 of 9 conversations')
 passed('browser Back and Forward',restored_search=True)
 search('luyện tiếng Anh')
 expect(page.locator('.results-meta')).to_have_text('9 of 9 conversations')
 page.locator('.conversation-item').first.click()
 expect(page.locator('h1')).to_contain_text('Kế hoạch')
 page.screenshot(path=str(ROOT/'screenshots/05-multilingual.png'),full_page=True)
 passed('Vietnamese search and rendering',query='luyện tiếng Anh',results=9)
 page.get_by_label('Search path',exact=True).select_option('current')
 search('alternative-snapshot-plan')
 # Search and reader share the same current/all path control.
 expect(page.locator('.results-meta')).to_have_text('0 of 0 conversations')
 page.get_by_label('Search path',exact=True).select_option('all')
 expect(page.locator('.results-meta')).to_have_text('1 of 1 conversations')
 page.locator('.conversation-item').first.click()
 expect(page.locator('h1')).to_contain_text('· 01')
 page.screenshot(path=str(ROOT/'screenshots/06-branch-search.png'),full_page=True)
 passed('branch search scope',query='alternative-snapshot-plan',current_results=0,all_results=1)
 search('')
 page.get_by_label('Search path',exact=True).select_option('current')
 expect(page.locator('.results-meta')).to_have_text('60 of 72 conversations')
 # A selected upload displays the actual application import panel.
 source=ROOT/'synthetic-ui-demo.zip';before=hashlib.sha256(source.read_bytes()).hexdigest()
 page.get_by_test_id('import-zip-input').set_input_files(str(source))
 expect(page.get_by_test_id('import-start-button')).to_be_visible()
 page.screenshot(path=str(ROOT/'screenshots/04-import.png'),full_page=True)
 page.get_by_test_id('import-start-button').click()
 expect(page.get_by_test_id('import-status')).to_contain_text('Import succeeded',timeout=60000)
 expect(page.get_by_test_id('import-summary')).to_contain_text('Warnings: 0')
 assert hashlib.sha256(source.read_bytes()).hexdigest()==before
 page.screenshot(path=str(ROOT/'screenshots/07-import-complete.png'),full_page=True)
 passed('browser ZIP import',summary=page.get_by_test_id('import-summary').inner_text(),source_zip_unchanged=True)
 assert not errors,errors
 assert not failures,failures
 assert not external,external
 passed('browser diagnostics',javascript_errors=errors,http_failures=failures,external_requests=external)
 browser.close()
print(json.dumps(results,indent=2,ensure_ascii=False))
